const normalizeUrl = (urlString, options) => {
	options = {
		defaultProtocol: 'http:',
		normalizeProtocol: true,
		forceHttp: false,
		forceHttps: false,
		stripAuthentication: true,
		stripHash: false,
		stripWWW: true,
		removeQueryParameters: [/^utm_\w+/i],
		removeTrailingSlash: true,
		removeDirectoryIndex: false,
		sortQueryParameters: true,
		...options
	};

	urlString = urlString.trim();

	const hasRelativeProtocol = urlString.startsWith('//');
	const isRelativeUrl = !hasRelativeProtocol && /^\.*\//.test(urlString);

	// Prepend protocol
	if (!isRelativeUrl) {
		urlString = urlString.replace(/^(?!(?:\w+:)?\/\/)|^\/\//, options.defaultProtocol);
	}

	const urlObj = new URL(urlString);

	if (options.forceHttp && options.forceHttps) {
		throw new Error('The `forceHttp` and `forceHttps` options cannot be used together');
	}

	if (options.forceHttp && urlObj.protocol === 'https:') {
		urlObj.protocol = 'http:';
	}

	if (options.forceHttps && urlObj.protocol === 'http:') {
		urlObj.protocol = 'https:';
	}

	// Remove auth
	if (options.stripAuthentication) {
		urlObj.username = '';
		urlObj.password = '';
	}

	// Remove hash
	if (options.stripHash) {
		urlObj.hash = '';
	}

	// Remove duplicate slashes if not preceded by a protocol
	if (urlObj.pathname) {
		urlObj.pathname = urlObj.pathname.replace(/(?<!https?:)\/{2,}/g, '/');
	}

	// Decode URI octets
	if (urlObj.pathname) {
		try {
			urlObj.pathname = decodeURI(urlObj.pathname);
		} catch (_) {}
	}

	// Remove directory index
	if (options.removeDirectoryIndex === true) {
		options.removeDirectoryIndex = [/^index\.[a-z]+$/];
	}

	if (Array.isArray(options.removeDirectoryIndex) && options.removeDirectoryIndex.length > 0) {
		let pathComponents = urlObj.pathname.split('/');
		const lastComponent = pathComponents[pathComponents.length - 1];

		if (testParameter(lastComponent, options.removeDirectoryIndex)) {
			pathComponents = pathComponents.slice(0, pathComponents.length - 1);
			urlObj.pathname = pathComponents.slice(1).join('/') + '/';
		}
	}

	if (urlObj.hostname) {
		// Remove trailing dot
		urlObj.hostname = urlObj.hostname.replace(/\.$/, '');

		// Remove `www.`
		if (options.stripWWW && /^www\.(?:[a-z\-\d]{2,63})\.(?:[a-z.]{2,5})$/.test(urlObj.hostname)) {
			// Each label should be max 63 at length (min: 2).
			// The extension should be max 5 at length (min: 2).
			// Source: https://en.wikipedia.org/wiki/Hostname#Restrictions_on_valid_host_names
			urlObj.hostname = urlObj.hostname.replace(/^www\./, '');
		}
	}

	// Remove query unwanted parameters
	if (Array.isArray(options.removeQueryParameters)) {
		for (const key of [...urlObj.searchParams.keys()]) {
			if (testParameter(key, options.removeQueryParameters)) {
				urlObj.searchParams.delete(key);
			}
		}
	}

	// Sort query parameters
	if (options.sortQueryParameters) {
		urlObj.searchParams.sort();
	}

	if (options.removeTrailingSlash) {
		urlObj.pathname = urlObj.pathname.replace(/\/$/, '');
	}

	// Take advantage of many of the Node `url` normalizations
	urlString = urlObj.toString();

	// Remove ending `/`
	if ((options.removeTrailingSlash || urlObj.pathname === '/') && urlObj.hash === '') {
		urlString = urlString.replace(/\/$/, '');
	}

	// Restore relative protocol, if applicable
	if (hasRelativeProtocol && !options.normalizeProtocol) {
		urlString = urlString.replace(/^http:\/\//, '//');
	}

	// Remove http/https
	if (options.stripProtocol) {
		urlString = urlString.replace(/^(?:https?:)?\/\//, '');
	}

	return urlString;
};
/// https://github.com/sindresorhus/normalize-url/blob/master/index.js

const getById = id => document.getElementById(id)
const getByClass = cl => document.getElementsByClassName(cl)

const requestDir = (dir = '') => ws.send(JSON.stringify({type:'dir', path: `${getByClass('current')[0].innerText.slice(1)}/` + dir}))
const download = dir => location.href = normalizeUrl(`${location.origin}/${getByClass('current')[0].innerText.slice(1)}/${dir}`)

const setType = type => {
  if (type === 'folder') return 'far fa-folder'
  if (['png', 'jpg', 'gif'].includes(type)) return 'far fa-file-image'
  if (['mp3'].includes(type)) return 'far fa-file-audio'
  if (['mp4', 'avi'].includes(type)) return 'far fa-file-video'
  if (['zip', 'tar'].includes(type)) return 'far fa-file-archive'
  if (['txt', 'md'].includes(type)) return 'far fa-file-alt'
  return 'far fa-file'
}

const updateDir = dir => {
  const current = getByClass('current')[0]
  current.innerHTML = '&nbsp;' + dir.current

  const ul = getByClass('fa-ul')[0]
  while(ul.firstChild) ul.removeChild(ul.firstChild)

  dir.files.forEach(x => {
    const name = x.name
    const type = x.type

    let li = document.createElement('li')
    let spanLi = document.createElement('span')
    let i = document.createElement('i')
    let spanRainbow = document.createElement('span')

    spanLi.setAttribute('class', 'fa-li')

    i.setAttribute('class', setType(type))
    i.setAttribute('aria-hidden', 'true')

    spanRainbow.setAttribute('class', 'rainbow')
    if (type === 'folder') spanRainbow.setAttribute('onclick', `requestDir('${name}')`)
    else spanRainbow.setAttribute('onclick', `download('${name}')`)
    spanRainbow.innerText = name
    
    spanLi.appendChild(i)

    li.appendChild(spanLi)
    li.appendChild(spanRainbow)

    ul.appendChild(li)
  })
}

const error = msg => 1

const ws = new WebSocket(`ws://${location.hostname}:3000`)
ws.onmessage = e => {
  const req = (() => { try{ return JSON.parse(e.data) } catch { return {type: 'error'} } })() 
  switch(req.type){
    case 'dir':
      updateDir(req.msg)
    case 'error':
    default:
      error(req.msg)
      break
  }
}
ws.onopen = function(){
  requestDir()
}

setInterval(requestDir, 5 * 60 * 1000)