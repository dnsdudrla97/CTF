const fs   = require('fs')

const send = (ws, type, msg) => ws.send(JSON.stringify({type, msg}))
const getType = name => name.split('.').pop()

const normalize = path => {
  const startSlash = path.charAt(0) === '/'
  const parts = path.split('/')
  let res = []

  for (let i=0; i < parts.length; i++) {
    if (!parts[i] || parts[i] === '.') continue
    if (parts[i] === '..') {
      if (res.length && res[res.length - 1] !== '..') res.pop()
    } else res.push(parts[i])
  }

  res = res.join('/')

  if (!res && !startSlash) {
    res = '.'
  }
  if (res && path[path.length - 1] === '/') {
    res += '/'
  }

  return (startSlash ? '/' : '') + res.replace('\\', '/')
}

const dir = (path = './files') => {
  if(!path.startsWith('./files')) path = './files/' + path
  const result = []
  const files = (()=> { try { if (fs.lstatSync(path) && fs.lstatSync(path).isDirectory()){ return fs.readdirSync(path) } else return [] } catch { return [] }})()

  files.forEach(name => {
    if (fs.lstatSync(path + '/' + name).isFile()) {
      const type = getType(name)
      result.push({name, type})
    } else {
      const type = 'folder'
      result.push({name, type})
    }
  })
  result.sort((a,b) => a.type == 'folder' ? a.type == b.type ? a.name < b.name ? -1 : a.name > b.name ? 1 : 0 : -1 : a.name < b.name ? -1 : a.name > b.name ? 1 : 0)
  result.unshift({'name':'..', 'type':'folder'})
  return result
}

module.exports = ws => {
  ws.on('message', msg => {
    const req = (() => { try{ return JSON.parse(msg) } catch (e) { return {type: 'error'} } })()

    switch(req.type){
      case 'dir':
        const current = typeof req.path === 'undefined' ? '/' : normalize('/' + req.path)
        const files = dir(current)
        send(ws, 'dir', {files, current})
        break
      case 'error':
      default:
        send(ws, 'error', 'error')
        break
    }
  })
}
