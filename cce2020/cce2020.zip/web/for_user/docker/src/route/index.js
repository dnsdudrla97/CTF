const router = require('express').Router()
const mime   = require('mime-types')
const fs     = require('fs')

router.get('/*', (req, res) => {
  if (req.params[0] === '') {
    res.render('index')
  } else {
    const path = './files/' + req.params[0]
    if (!fs.existsSync(path)) {
      res.status(403).send('<h1>403 Not Found.</h1>')
      return
    }

    if (fs.lstatSync(path).isDirectory()) {
      res.status(301).redirect('/')
      return
    }
    res.set('Content-Type', mime.lookup(path))
    res.sendFile(path, {root: '.'})
  }
})

module.exports = router
