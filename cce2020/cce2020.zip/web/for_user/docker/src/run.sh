#!/bin/sh
cd /usr/src/app
forever app.js
