const express = require('express')
const ws = require('ws')
const app = express()
const __DIR = '/usr/src/app'

/* express */
app.set('views', __DIR + '/views');
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const index = require(__DIR + '/route/index')

app.use(index)

/* WebSocket */
const server = new ws.Server({port: 3000})

const connection = require(__DIR + '/route/ws')
server.on('connection', connection)

app.listen(80)
