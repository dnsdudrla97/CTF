<?php
	include('./config.php');

	if(!is_login()) alert('로그인 권한이 필요합니다', './login.php');

	if($_POST){
		$replace = array();
		
		if(trim($_POST['pw'])){
			$replace['pw'] = sha1($pw . __SALT__);
		}

		if(trim($_POST['note']) === 'enable'){
			$replace['is_note'] = '1';
		}
		else{
			$replace['is_note'] = '0';	
		}

		$search = array('idx' => $_SESSION['idx']);
		if(update('user', $replace, $search)){
			foreach ($replace as $key => $value) {
				$_SESSION[$key] = clean_sql($value);
			}
			alert('변경 되었습니다', './myinfo.php');
		}
		else{
			alert('에러 발생', './myinfo.php');
		}
		exit;
	}

	render_page('myinfo');
?>