<?php
	if(!defined('__MAIN__')) exit('!^_^!');

	include(__TEMPLATE__ . 'head.php');

?>
	<main role="main" class="container">
		<div class="jumbotron">
			<h1>CMSAGAIN</h1>
			<p class="lead">한국에서 제일 가는 CMS! CMSAGAIN을 무료로 만나 보세요</p>
		</div>
	</main>
<?php
	include(__TEMPLATE__ . 'tail.php');
?>

