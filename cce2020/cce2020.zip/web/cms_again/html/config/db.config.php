<?php
	$dbcon = mysqli_connect("db", "cmsagain", "cmsagain111!", "cmsagain");
?>